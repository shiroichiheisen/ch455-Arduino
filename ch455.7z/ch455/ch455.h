#ifndef ch_455
#define ch_455

#include <Arduino.h>

class ch455
{
public:
	ch455(int pin_sda, int pin_scl, int led_bright, int sevenOReight_segments, int sleep, int ena);
	void d0(String digit0, int dot);
	void d1(String digit1, int dot);
	void d2(String digit2, int dot);
	void d3(String digit3, int dot);
	void d0(int digit0, int dot);
	void d1(int digit1, int dot);
	void d2(int digit2, int dot);
	void d3(int digit3, int dot);
	void alld(int digit0, int dot0, int digit1, int dot1, int digit2, int dot2, int digit3, int dot3);
	void alld(int digit0, int dot0, int digit1, int dot1, int digit2, int dot2);
	void alld(int digit0, int dot0, int digit1, int dot1);
	void alld(String digit0, int dot0, String digit1, int dot1, String digit2, int dot2, String digit3, int dot3);
	void alld(String digit0, int dot0, String digit1, int dot1, String digit2, int dot2);
	void alld(String digit0, int dot0, String digit1, int dot1);
private:
int _led_bright,_ready;
String _led_brightS,_sevenOReight_segments, _sleep, _ena, _all,_dig,_sum,_dot;
};

#endif
