#include "ch455.h"
#include <Wire.h>

ch455::ch455(int pin_sda, int pin_scl, int led_bright, int sevenOReight_segments, int sleep, int ena)
{
    if (led_bright > 8)
    {
        _led_bright = 8;
    }
    if (led_bright < 1)
    {
        _led_bright = 1;
    }
    switch (_led_bright)
    {
    case 1:
        _led_brightS = "000";
        break;
    case 2:
        _led_brightS = "001";
        break;
    case 3:
        _led_brightS = "010";
        break;
    case 4:
        _led_brightS = "011";
        break;
    case 5:
        _led_brightS = "100";
        break;
    case 6:
        _led_brightS = "101";
        break;
    case 7:
        _led_brightS = "110";
        break;
    case 8:
        _led_brightS = "111";
        break;
    }
    if (sevenOReight_segments >= 1)
    {
        _sevenOReight_segments = "1";
    }
    if (sevenOReight_segments <= 0)
    {
        _sevenOReight_segments = "0";
    }

    if (sleep >= 1)
    {
        _sleep = "1";
    }
    if (sleep <= 0)
    {
        _sleep = "0";
    }

    if (ena >= 1)
    {
        _ena = "1";
    }
    if (ena <= 0)
    {
        _ena = "0";
    }
    _all = "0" + _led_brightS + _sevenOReight_segments + _sleep + "0" + _ena;
    _ready = _all.toInt();

    Wire.begin(pin_sda, pin_scl);
    Wire.beginTransmission(36);
    Wire.write(_ready);
    Wire.endTransmission();
}

void ch455::d0(String digito0, int dot)
{
    if (dot >= 1)
    {
        _dot = "1";
    }
    if (dot <= 0)
    {
        _dot = "0";
    }
    if (digito0.toInt())
    {
        switch (digito0.toInt())
        {
        case 0:
            _sum = _dot + "0111111";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
            break;
        case 1:
            _sum = _dot + "0000110";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
            break;
        case 2:
            _sum = _dot + "1011011";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
            break;
        case 3:
            _sum = _dot + "1001111";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
            break;
        case 4:
            _sum = _dot + "1111110";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
            break;
        case 5:
            _sum = _dot + "1101101";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
            break;
        case 6:
            _sum = _dot + "1111101";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
            break;
        case 7:
            _sum = _dot + "0100111";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
            break;
        case 8:
            _sum = _dot + "1111111";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
            break;
        case 9:
            _sum = _dot + "1101111";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
            break;
        }
    }
    else
    {
        if(digito0.equalsIgnoreCase("a")){
            _sum = _dot + "1110111";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("c")){
            _sum = _dot + "0111001";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("d")){
            _sum = _dot + "1011110";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("e")){
            _sum = _dot + "1111001";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("f")){
            _sum = _dot + "1110001";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("h")){
            _sum = _dot + "1110110";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("i")){
            _sum = _dot + "0110000";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("j")){
            _sum = _dot + "0011110";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("l")){
            _sum = _dot + "0111000";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("n")){
            _sum = _dot + "0110111";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("o")){
            _sum = _dot + "0111111";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("p")){
            _sum = _dot + "1111111";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("r")){
            _sum = _dot + "1110011";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("s")){
            _sum = _dot + "1101101";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("t")){
            _sum = _dot + "1111000";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("u")){
            _sum = _dot + "0111110";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("V")){
            _sum = _dot + "0111110";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("x")){
            _sum = _dot + "1110110";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("y")){
            _sum = _dot + "1101110";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
        if(digito0.equalsIgnoreCase("z")){
            _sum = _dot + "1011011";
            Wire.beginTransmission(52);
            Wire.write(_sum.toInt());
            Wire.endTransmission();
        }
    }
}
